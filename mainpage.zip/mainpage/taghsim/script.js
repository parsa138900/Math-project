function calculate() {
    var xx = parseFloat(document.getElementById("xx").value);
    var yy = parseFloat(document.getElementById("yy").value);

    if (isNaN(xx) || isNaN(yy)) {
        document.getElementById("px").innerHTML = "لطفاً مقادیر عددی معتبر وارد کنید.";
        return;
    }

    if (yy === 0) {
        document.getElementById("px").innerHTML = "تقسیم بر صفر مجاز نیست.";
        return;
    }

    var rr = xx / yy;
    var ans = "جواب = " + rr;
    document.getElementById("px").innerHTML = ans;
}

// دریافت عناصر دکمه و پنجره
var button = document.getElementById("myButton");
var modal = document.getElementById("myModal");
var closeButton = document.getElementsByClassName("close")[0];

// اضافه کردن رویداد کلیک به دکمه
button.onclick = function() {
  modal.style.display = "block"; // نمایش پنجره
  setTimeout(function() {
    modal.classList.add("show"); // افزودن کلاس show برای اجرای انیمیشن
  }, 10); // تاخیر کوتاه برای اجرای انیمیشن
}

// اضافه کردن رویداد کلیک به دکمه بستن
closeButton.onclick = function() {
  modal.classList.remove("show"); // حذف کلاس show برای اجرای انیمیشن بستن
  setTimeout(function() {
    modal.style.display = "none"; // مخفی کردن پنجره بعد از انیمیشن
  }, 500); // تاخیر برای اجرای انیمیشن بستن
}

// بستن پنجره با کلیک خارج از آن
window.onclick = function(event) {
  if (event.target == modal) {
    modal.classList.remove("show");
    setTimeout(function() {
      modal.style.display = "none";
    }, 500);
  }
}