let inputCount = 2; // تعداد اولیه ورودی‌ها

function addInput() {
    inputCount++;
    const newInput = document.createElement("div");
    newInput.innerHTML = `
        <label for="item${inputCount}">ورودی ${inputCount}:</label>
        <input type="text" id="item${inputCount}" name="item${inputCount}"><br><br>
    `;
    document.getElementById("numberInputs").appendChild(newInput);
}

function removeInput() {
    if (inputCount > 1) {
        document.getElementById("numberInputs").lastChild.remove();
        inputCount--;
    }
}

function calculateSubsets() {
    const elements = [];
    for (let i = 1; i <= inputCount; i++) {
        const value = document.getElementById(`item${i}`).value;
        if (value !== "") {
            elements.push(value);
        }
    }

    const subsets = [];

    function generateSubsets(index, currentSubset) {
        if (index === elements.length) {
            subsets.push(currentSubset.slice());
            return;
        }

        generateSubsets(index + 1, currentSubset);
        currentSubset.push(elements[index]);
        generateSubsets(index + 1, currentSubset);
        currentSubset.pop();
    }

    generateSubsets(0, []);

    const resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "<h2>زیرمجموعه‌ها:</h2>";

    subsets.forEach(subset => {
        resultDiv.innerHTML += "<p>{" + subset.join(", ") + "}</p>";
    });

    resultDiv.innerHTML += `<p>تعداد زیرمجموعه‌ها: ${subsets.length}</p>`;
}
// دریافت عناصر دکمه و پنجره
var button = document.getElementById("myButton");
var modal = document.getElementById("myModal");
var closeButton = document.getElementsByClassName("close")[0];

// اضافه کردن رویداد کلیک به دکمه
button.onclick = function() {
  modal.style.display = "block"; // نمایش پنجره
  setTimeout(function() {
    modal.classList.add("show"); // افزودن کلاس show برای اجرای انیمیشن
  }, 10); // تاخیر کوتاه برای اجرای انیمیشن
}

// اضافه کردن رویداد کلیک به دکمه بستن
closeButton.onclick = function() {
  modal.classList.remove("show"); // حذف کلاس show برای اجرای انیمیشن بستن
  setTimeout(function() {
    modal.style.display = "none"; // مخفی کردن پنجره بعد از انیمیشن
  }, 500); // تاخیر برای اجرای انیمیشن بستن
}

// بستن پنجره با کلیک خارج از آن
window.onclick = function(event) {
  if (event.target == modal) {
    modal.classList.remove("show");
    setTimeout(function() {
      modal.style.display = "none";
    }, 500);
  }
}