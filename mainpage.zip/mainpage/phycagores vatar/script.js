var a = document.getElementById("mohammad");
var b = document.getElementById("dana");
var resultDiv = document.getElementById("result"); // عنصر نمایش پاسخ

function mahdi(c, d) {
    var vatar = Math.sqrt((c * c) + (d * d));
    resultDiv.textContent = "نتیجه: " + vatar; // نمایش پاسخ در عنصر result
}

var btn = document.getElementById("mybtn");

function show() {
    // تبدیل مقادیر ورودی به عدد
    var c = parseFloat(a.value);
    var d = parseFloat(b.value);

    // چک کردن اینکه ورودی ها عدد هستند یا نه
    if (isNaN(c) || isNaN(d)) {
        resultDiv.textContent = "لطفا مقادیر عددی وارد کنید!"
        return;
    }

    mahdi(c, d);
}

// درست کردن event listener
btn.addEventListener('click', show);

// دریافت عناصر دکمه و پنجره
var button = document.getElementById("myButton");
var modal = document.getElementById("myModal");
var closeButton = document.getElementsByClassName("close")[0];

// اضافه کردن رویداد کلیک به دکمه
button.onclick = function() {
  modal.style.display = "block"; // نمایش پنجره
  setTimeout(function() {
    modal.classList.add("show"); // افزودن کلاس show برای اجرای انیمیشن
  }, 10); // تاخیر کوتاه برای اجرای انیمیشن
}

// اضافه کردن رویداد کلیک به دکمه بستن
closeButton.onclick = function() {
  modal.classList.remove("show"); // حذف کلاس show برای اجرای انیمیشن بستن
  setTimeout(function() {
    modal.style.display = "none"; // مخفی کردن پنجره بعد از انیمیشن
  }, 500); // تاخیر برای اجرای انیمیشن بستن
}

// بستن پنجره با کلیک خارج از آن
window.onclick = function(event) {
  if (event.target == modal) {
    modal.classList.remove("show");
    setTimeout(function() {
      modal.style.display = "none";
    }, 500);
  }
}