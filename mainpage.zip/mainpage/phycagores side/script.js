var vate = document.getElementById("vat");
var zele = document.getElementById("zel");
var resultDiv = document.getElementById("result"); // عنصر نمایش پاسخ

function mohsen(g, s) {
    var mohasebeh = Math.sqrt((g * g) - (s * s));
    resultDiv.textContent = "نتیجه: " + mohasebeh; // نمایش پاسخ در عنصر result
}

var buttonn = document.getElementById("mybtn"); // اصلاح id

function bomb() {
    // تبدیل مقادیر ورودی به عدد
    var g = parseFloat(vate.value);
    var s = parseFloat(zele.value);

    // چک کردن اینکه ورودی ها عدد هستند یا نه
    if (isNaN(g) || isNaN(s)) {
        resultDiv.textContent = "لطفا مقادیر عددی وارد کنید!"
        return;
    }
    mohsen(g, s);
}

// دریافت عناصر دکمه و پنجره
var button = document.getElementById("myButton");
var modal = document.getElementById("myModal");
var closeButton = document.getElementsByClassName("close")[0];

// اضافه کردن رویداد کلیک به دکمه
button.onclick = function() {
  modal.style.display = "block"; // نمایش پنجره
  setTimeout(function() {
    modal.classList.add("show"); // افزودن کلاس show برای اجرای انیمیشن
  }, 10); // تاخیر کوتاه برای اجرای انیمیشن
}

// اضافه کردن رویداد کلیک به دکمه بستن
closeButton.onclick = function() {
  modal.classList.remove("show"); // حذف کلاس show برای اجرای انیمیشن بستن
  setTimeout(function() {
    modal.style.display = "none"; // مخفی کردن پنجره بعد از انیمیشن
  }, 500); // تاخیر برای اجرای انیمیشن بستن
}

// بستن پنجره با کلیک خارج از آن
window.onclick = function(event) {
  if (event.target == modal) {
    modal.classList.remove("show");
    setTimeout(function() {
      modal.style.display = "none";
    }, 500);
  }
}